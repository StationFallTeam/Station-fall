import pygame
import asyncio

from player import Player
from enemy import Enemy
from render import draw_objects

async def main():
    pygame.init()
    pygame.mixer.init()

    screen_width = 500
    screen_height = 500
    win = pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("Station Fall Playtest")

    clock = pygame.time.Clock()

    player = Player(100, 100)
    enemies = [Enemy(300, 300)]

    running = True
    while running:
        clock.tick(60)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                running = False

        keys = pygame.key.get_pressed()

        player.update(keys, screen_width, screen_height)

        for enemy in enemies:
            enemy.update(player.get_rect())

        win.fill((0, 0, 0))
        draw_objects(win, player, enemies)
        pygame.display.flip()

        await asyncio.sleep(0)

    pygame.quit()

asyncio.run(main())


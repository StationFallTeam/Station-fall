import pygame
import math
from src.ui import draw_health_bar, draw_money, draw_runs
from dungeongen.classes import CombatRoom
from src.assets import resolve_asset_path

# Pause menu - Wil
def draw_pause_menu(win, screen_width, screen_height, base_seed=None, active_seed=None, run_count=None):
    overlay = pygame.Surface((screen_width, screen_height), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 160))
    win.blit(overlay, (0, 0))

    title_font = pygame.font.SysFont(None, 72)
    btn_font = pygame.font.SysFont(None, 48)

    title = title_font.render("PAUSED", True, (255, 255, 255))
    win.blit(title, title.get_rect(center=(screen_width // 2, screen_height // 2 - 160)))

    seed_font = pygame.font.SysFont(None, 28)
    info_lines = []
    if base_seed is not None:
        info_lines.append(f"Base Seed: {base_seed}")
    if active_seed is not None:
        info_lines.append(f"Active Seed: {active_seed}")
    if run_count is not None:
        info_lines.append(f"Run: {run_count}")
    line_y = screen_height // 2 - 110
    for line in info_lines:
        surf = seed_font.render(line, True, (200, 200, 200))
        win.blit(surf, surf.get_rect(center=(screen_width // 2, line_y)))
        line_y += seed_font.get_linesize() + 2

    btn_w, btn_h = 260, 60
    mx, my = pygame.mouse.get_pos()

    def make_btn(label, cy):
        rect = pygame.Rect(0, 0, btn_w, btn_h)
        rect.center = (screen_width // 2, cy)
        hover = rect.collidepoint(mx, my)
        color = (220, 220, 220) if hover else (170, 170, 170)
        pygame.draw.rect(win, color, rect, border_radius=12)
        pygame.draw.rect(win, (40, 40, 40), rect, 3, border_radius=12)
        lbl = btn_font.render(label, True, (0, 0, 0))
        win.blit(lbl, lbl.get_rect(center=rect.center))
        return rect

    resume_rect = make_btn("Resume",    screen_height // 2 + 10)
    menu_rect   = make_btn("Main Menu", screen_height // 2 + 100)
    quit_rect   = make_btn("Quit",      screen_height // 2 + 190)

    return resume_rect, menu_rect, quit_rect

def draw_objects(win, player, enemies, bullets, camera, background, coins, floating_texts, dungeon, tile_size, dungeon_runs=0):
    # 1. Draw the parallax background first using camera position
    background.update_and_draw(win, (camera.camera.x, camera.camera.y))

    # 2. Draw dungeon or walls
    if dungeon and dungeon.draw:
        # Use dungeon rendering pipeline instead of manual walls
        # Use provided tile_size or fall back to dungeon's tile_size
        render_tile_size = tile_size or dungeon.tile_size
        dungeon.draw(
            surface=win,
            tile_size=render_tile_size,
            cam_x=-camera.camera.x,
            cam_y=-camera.camera.y,
            show_grid=False,
            show_sprites=True,
        )
    
    if dungeon and dungeon.rooms and tile_size:
        # Let each combat room draw its own spawn warnings
        for room in dungeon.rooms:
            if isinstance(room, CombatRoom):
                room.draw_spawn_warnings(win, camera, tile_size)

    # 3. Draw entities relative to camera
    for coin in coins:
        coin.draw(win, camera)

    for bullet in bullets: 
        bullet.draw(win, camera)

    for enemy in enemies:
        enemy.draw(win, camera)

    # 4. Draw the player (passing camera for offset)
    player.draw(win, camera)

    # 5. Draw Floating Action Text (Damage numbers, etc.)
    # We draw these after entities so they appear on top of characters
    for ft in floating_texts:
        ft.draw(win, camera)

    # 6. Draw Fixed HUD elements (Screen Space)
    # Player HUD health bar
    draw_health_bar(win, player.health, player.max_health, 20, 20, 250, 18)
    draw_money(win, player.money, 20, 50)
    draw_runs(win, dungeon_runs, 260, 50)

    # 7. Draw hovering enemy health bars (World Space)
    for enemy in enemies:
        screen_rect = camera.apply(enemy.rect)
        
        draw_health_bar(
            win,
            enemy.health,
            enemy.max_health,
            screen_rect.x,
            screen_rect.y - 10,
            screen_rect.width,
            6,
            border=1
        )

def apply_brightness(win, brightness):
    if brightness >= 1.0:
        return
    
    darkness = int((1.0 - brightness) * 255)
    
    overlay = pygame.Surface(win.get_size())
    overlay.fill((0, 0, 0))
    overlay.set_alpha(darkness)

    win.blit(overlay, (0, 0))

def draw_menu(win, screen_width, screen_height, truck_img, float_time):

    title_font = pygame.font.SysFont(None, 90)
    small_font = pygame.font.SysFont(None, 32)
    btn_font = pygame.font.SysFont(None, 48)

    # Title
    title = title_font.render("STATION FALL", True, (255, 255, 255))
    win.blit(title, title.get_rect(center=(screen_width // 2, screen_height // 2 - 180)))

    hint = small_font.render("Press ENTER to start", True, (200, 200, 200))
    win.blit(hint, hint.get_rect(center=(screen_width // 2, screen_height // 2 - 120)))

    #ship
    float_offset = math.sin(float_time) * 15
    truck_rect = truck_img.get_rect()
    truck_rect.center = (screen_width // 2, screen_height // 2 + float_offset)
    win.blit(truck_img, truck_rect)

    # Buttons
    btn_w, btn_h = 260, 60
    start_rect = pygame.Rect(0, 0, btn_w, btn_h)
    start_rect.center = (screen_width // 2, screen_height // 2 + 140)

    credits_rect = pygame.Rect(0, 0, btn_w, btn_h)
    credits_rect.center = (screen_width // 2, screen_height // 2 + 230)

    quit_rect = pygame.Rect(0, 0, btn_w, btn_h)
    quit_rect.center = (screen_width // 2, screen_height // 2 + 320)

    mx, my = pygame.mouse.get_pos()

    def draw_button(rect, text):
        hover = rect.collidepoint(mx, my)
        color = (220, 220, 220) if hover else (170, 170, 170)
        pygame.draw.rect(win, color, rect, border_radius=12)
        pygame.draw.rect(win, (40, 40, 40), rect, 3, border_radius=12)

        label = btn_font.render(text, True, (0, 0, 0))
        win.blit(label, label.get_rect(center=rect.center))

    draw_button(start_rect, "Start")
    draw_button(credits_rect, "Credits")
    draw_button(quit_rect, "Quit")

    ver = small_font.render("v1.3.1", True, (200, 200, 200))
    win.blit(ver, ver.get_rect(center=(screen_width - 35, screen_height - 15)))

    return start_rect, quit_rect, credits_rect


def draw_game_settings_menu(win, screen_width, screen_height, truck_img, float_time, seed_text, seed_input_active=False):
    title_font = pygame.font.SysFont(None, 90)
    small_font = pygame.font.SysFont(None, 32)
    btn_font = pygame.font.SysFont(None, 48)

    title = title_font.render("GAME SETTINGS", True, (255, 255, 255))
    win.blit(title, title.get_rect(center=(screen_width // 2, screen_height // 2 - 180)))

    hint = small_font.render("Set base seed and begin", True, (200, 200, 200))
    win.blit(hint, hint.get_rect(center=(screen_width // 2, screen_height // 2 - 120)))

    #ship — floats independently, buttons are anchored to a fixed Y
    float_offset = math.sin(float_time) * 15
    truck_rect = truck_img.get_rect()
    truck_rect.center = (screen_width // 2, screen_height // 2 + float_offset)
    win.blit(truck_img, truck_rect)

    mx, my = pygame.mouse.get_pos()

    # Fixed anchor below where the truck sits at rest (no float influence)
    truck_base_y = screen_height // 2 + truck_img.get_height() // 2

    seed_label = small_font.render("Base Seed", True, (220, 220, 220))
    win.blit(seed_label, seed_label.get_rect(center=(screen_width // 2, truck_base_y + 35)))

    seed_input_rect = pygame.Rect(0, 0, 320, 44)
    seed_input_rect.center = (screen_width // 2, truck_base_y + 70)
    input_hover = seed_input_rect.collidepoint(mx, my)
    input_color = (220, 220, 220) if (seed_input_active or input_hover) else (170, 170, 170)
    pygame.draw.rect(win, input_color, seed_input_rect, border_radius=12)
    pygame.draw.rect(win, (40, 40, 40), seed_input_rect, 3, border_radius=12)

    seed_value_surface = small_font.render(seed_text or "0", True, (0, 0, 0))
    win.blit(seed_value_surface, seed_value_surface.get_rect(center=seed_input_rect.center))

    btn_w, btn_h = 260, 60
    random_seed_rect = pygame.Rect(0, 0, btn_w, btn_h)
    random_seed_rect.center = (screen_width // 2, truck_base_y + 145)

    begin_game_rect = pygame.Rect(0, 0, btn_w, btn_h)
    begin_game_rect.center = (screen_width // 2, truck_base_y + 225)

    back_rect = pygame.Rect(0, 0, btn_w, btn_h)
    back_rect.center = (screen_width // 2, truck_base_y + 305)

    def draw_button(rect, text):
        hover = rect.collidepoint(mx, my)
        color = (220, 220, 220) if hover else (170, 170, 170)
        pygame.draw.rect(win, color, rect, border_radius=12)
        pygame.draw.rect(win, (40, 40, 40), rect, 3, border_radius=12)

        label = btn_font.render(text, True, (0, 0, 0))
        win.blit(label, label.get_rect(center=rect.center))

    draw_button(random_seed_rect, "Random Seed")
    draw_button(begin_game_rect, "Begin Game")
    draw_button(back_rect, "Back")

    ver = small_font.render("v1.3.1", True, (200, 200, 200))
    win.blit(ver, ver.get_rect(center=(screen_width - 35, screen_height - 15)))

    return begin_game_rect, random_seed_rect, seed_input_rect, back_rect

# Game over screen
def draw_game_over(win, screen_width, screen_height, truck_img, float_time):
    font = pygame.font.SysFont(None, 90)
    small_font = pygame.font.SysFont(None, 32)

    text = font.render("GAME OVER", True, (255, 0, 0))
    hint = small_font.render("Press ESC to go back to main menu", True, (255, 255, 255))

    win.blit(text, text.get_rect(center=(screen_width//2, screen_height//2 - 50)))
    win.blit(hint, hint.get_rect(center=(screen_width//2, screen_height//2 + 50)))

    # Floating truck (top of screen)
    float_offset = math.sin(float_time) * 15
    truck_rect = truck_img.get_rect()
    truck_rect.midtop = (screen_width // 2, 200 + int(float_offset))
    win.blit(truck_img, truck_rect)

# Credits screen - Wil
def draw_credits(win, screen_width, screen_height, background, float_time, menu_camera_x, menu_camera_y, truck_img):

    title_font = pygame.font.SysFont(None, 72)
    name_font  = pygame.font.SysFont(None, 36)
    role_font  = pygame.font.SysFont(None, 26)
    hint_font  = pygame.font.SysFont(None, 28)
    sub_font   = pygame.font.SysFont(None, 21)

    team = [
        ("Wil Nahra",             "| Developer | Sprite Creation |"),
        ("Simon Halaszi",         "| Developer | Dungeon Master |"),
        ("Meheraj Khatri",        "| Developer | UI & Mechanics | QA Lead |"),
        ("Loy Ngo",               "| Developer | Navigation System | UI/Menu Systems |"),
        ("Rowan Ess",             "| Developer | Music |"),
        ("Sebastian Betancourt", "| Developer | Web Deployment | Build Pipeline |"),
        ("Yusairah Haque",        "| Developer | Enemy AI | Combat Mechanics |"),
        ("Zachary Evans",         "| Developer | Enemy Creator | Writer"),
    ]

    SCROLL_SPEED = 50       # px/sec leftward scroll
    ENTRY_GAP    = 400      # horizontal gap between each entry
    BOB_SPEED    = 1.5      # how fast each entry bobs
    BOB_AMP      = 18       # how many pixels up/down each entry floats

    total_strip_w = len(team) * ENTRY_GAP

    # Background
    background.update_and_draw(win, (menu_camera_x, menu_camera_y))
    credit_y = int(screen_height * 0.30)

    # Clip to avoid overlapping title and truck area
    clip_rect = pygame.Rect(0, 110, screen_width, int(screen_height * 0.52) - 110)
    win.set_clip(clip_rect)

    # Scroll offset — right to left
    scroll_x = (float_time * SCROLL_SPEED) % total_strip_w

    for repeat in range(2):
        base_x = screen_width + repeat * total_strip_w - scroll_x

        for i, (name, role) in enumerate(team):
            cx = base_x + i * ENTRY_GAP

            if cx + 300 < 0 or cx - 300 > screen_width:
                continue

            # Each entry bobs independently w/ offset
            bob = math.sin(float_time * BOB_SPEED + i * 0.8) * BOB_AMP

            cy = credit_y + int(bob)

            name_surf = name_font.render(name, True, (220, 220, 255))
            role_surf = role_font.render(role, True, (140, 140, 200))
            win.blit(name_surf, name_surf.get_rect(center=(cx, cy)))
            win.blit(role_surf, role_surf.get_rect(center=(cx, cy + 30)))

    win.set_clip(None)

    # Truck uses the same centered float logic as the other menus
    float_offset = math.sin(float_time) * 15
    truck_rect = truck_img.get_rect()
    truck_rect.center = (screen_width // 2, screen_height // 2 + float_offset)
    win.blit(truck_img, truck_rect)

    # Title
    title = title_font.render("CREDITS", True, (255, 255, 255))
    win.blit(title, title.get_rect(center=(screen_width // 2, 55)))
    pygame.draw.line(win, (100, 100, 255),
                     (screen_width // 2 - 180, 95),
                     (screen_width // 2 + 180, 95), 1)

    #  Pokemon credit
    sub_text = sub_font.render("Most sprites are adapted from Pokemon Emerald", True, (120, 120, 120))
    sub_y = truck_rect.bottom + 40
    win.blit(sub_text, sub_text.get_rect(center=(screen_width // 2, sub_y)))

    # ESC hint
    hint = hint_font.render("Press ESC to return", True, (120, 120, 120))
    win.blit(hint, hint.get_rect(center=(screen_width // 2, screen_height - 30)))

# Making the shop
def draw_shop(win, screen_width, screen_height, player_gold, shop_items):

    item_rects = []  # Will store rects for each item
    
    # Background overlay 
    overlay = pygame.Surface((screen_width, screen_height), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180))  # slightly darker
    win.blit(overlay, (0, 0))
    
    # Top bar 
    top_bar_rect = pygame.Rect(0, 0, screen_width, 80)
    pygame.draw.rect(win, (255, 255, 255), top_bar_rect)
    pygame.draw.line(win, (255, 165, 0), (0, 80), (screen_width, 80), 3)
    
    # bottom bar
    bar_height = 150  # height of the bottom bar
    bottom_bar_rect = pygame.Rect(0, screen_height - bar_height, screen_width, bar_height)
    pygame.draw.rect(win, (255, 255, 255), bottom_bar_rect)
    # Optional: top border line
    pygame.draw.line(win, (255, 165, 0), (0, screen_height - bar_height), (screen_width, screen_height - bar_height), 3)

    # Shop logo
    shop_logo = pygame.image.load("sprites/shop/logo.jpg")
    shop_logo = pygame.transform.scale(shop_logo, (120, 60))
    win.blit(shop_logo, (20, 10))
    
    # Player gold
    money_font = pygame.font.SysFont(None, 36)
    money_text = money_font.render(f"Space Bucks: ${player_gold}", True, (0, 0, 0))
    win.blit(money_text, (screen_width - 250, 20))
    
    # Items grid
    card_w, card_h = 220, 120
    padding_x, padding_y = 40, 30
    start_x, start_y = 60, 120
    
    mx, my = pygame.mouse.get_pos()
    
    for idx, item in enumerate(shop_items):
        col = idx % 3
        row = idx // 3
        x = start_x + col * (card_w + padding_x)
        y = start_y + row * (card_h + padding_y)
        card_rect = pygame.Rect(x, y, card_w, card_h)
        item_rects.append(card_rect)  # <-- add to list
        
        # Hover effect
        hover = card_rect.collidepoint(mx, my)
        color = (255, 255, 230) if hover else (240, 240, 240)
        pygame.draw.rect(win, color, card_rect, border_radius=12)
        pygame.draw.rect(win, (100, 100, 100), card_rect, 3, border_radius=12)
        
        # Item info
        font = pygame.font.SysFont(None, 28)
        name_text = font.render(item["name"], True, (0, 0, 0))
        price_text = font.render(f"${item['price']}", True, (50, 150, 50))
        win.blit(name_text, (x + 10, y + 10))
        win.blit(price_text, (x + 10, y + 40))
        
        if "image" in item:
            img = pygame.transform.scale(item["image"], (60, 60))
            win.blit(img, (x + card_w - 90, y + 40))
    
    return item_rects
